/********************************************************************************
* FILE DESCRIBTION
* -------------------------------------------------------------------------------
*      File: intCtrl_Types.h
*      Module: -
*  
*    Describtion: header file for interruptctri_Types
*
********************************************************************************/

#ifnedf INTCTRL_TYPES_H
#define INTCTRL_TYPES_H
 

/********************************************************************************
* INCLUDES
********************************************************************************/

/********************************************************************************
* GLOBAL CONSTANT MACORS 
********************************************************************************/


/********************************************************************************
* GLOBAL CONSTANT FUNCTION
********************************************************************************/

/********************************************************************************
* GLOBAL DATA TYPES AND STRUCTURES
********************************************************************************/
/*
typedef enum
{
	GPIO_PortA,
	GPIO_PortB,
	GPIO_PortC,
	GPIO_PortD,
	GPIO_PortE,
	UART0,
	UART1,
	SSI0,
	I2C0,
	PWM0_Fault,
	PWM0_Generator0,
	PWM0_Generator1,
    PWM0_Generator2,
	QEI0,
	ADC0_Sequence0,
	ADC0_Sequence1,
	ADC0_Sequence2,
	ADC0_Sequence3,
	Watchdog Timers0and_1,
	Timer_0A,
	Timer_0B,
	Timer_1A,
	Timer_1B,
	Timer_2A,
	Timer_2B,
	AnalogComparator0,
	AnalogComparator1,
	SystemControl = 28,
	
	


	
	 
}IntCtrl_InterruptType;
typedef enum
{
	
	Reset = 1,
	Non-Maskable Interrupt,
	Hard_Fault,
	Memory Management,
	Bus_Fault,
	Usage Fault,
    SVCall = 11,
	Debug Monitor,
	PendSV = 14,
	SysTick = 15
}IntCtrl_ExceptionType;
*/


#endif 

/********************************************************************************
* END OF FILE: int_Ctrl_Types.h
********************************************************************************/






