/********************************************************************************
* FILE DESCRIBTION
* -------------------------------------------------------------------------------
*      File: std_Types.h
*      Module:  -
*
*  Description:  <Write File DESCRIPTION here>   
*
********************************************************************************/

#ifndef  SYSTIC_CTRL_H
#define  SYSTIC_CTRL_H 

#include "std_Types.h"

#define COUNT_1MSEC       16000
#define COUNT_1SEC        16000000

void SysTic_Init(uint8 ms);
	




#endif